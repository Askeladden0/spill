repo: Askeladden0/spill
branch: main

## Last sync
date: 2026-08-18T05:39:18Z

### Updated in this project
- Laget cover-bilde (800×500 SVG) for alle 6 spill i `assets/img/games/`
- Laget lite kvadratisk ikon (64×64 SVG) for alle 6 spill i `assets/img/icons/`
- `js/games-data.js`: `thumbnail` + nytt `icon`-felt satt for hvert spill
- `js/main.js` + `css/style.css`: cover vises i spillkort og hero-seksjonen
- Fargene hentet fra avatar-paletten i `supabase/schema.sql` (admin.html › Standard profilbilde – farger)

## Screen map
| Skjerm | Bygget fra |
| --- | --- |
| Spill cover.dc.html (hjemmeside-forhåndsvisning) | index.html, js/main.js, js/games-data.js, css/style.css |
| Cover + ikoner | supabase/schema.sql (avatar_options.colors), admin.html |
